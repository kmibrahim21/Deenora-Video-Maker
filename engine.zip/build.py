#!/usr/bin/env python3
"""input/voice.mp3 + input/script.txt -> output/video.mp4 (fully automatic).
  python build.py                # full video
  python build.py --seconds 8    # quick test
"""
import argparse, json, math, os, shutil, subprocess, sys, time
from multiprocessing import Pool
from pathlib import Path
HERE = Path(__file__).parent.resolve()
sys.path.insert(0, str(HERE))
import make_timeline

def chunk(a):
    html, frames, s, e, fps = a
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        b = p.chromium.launch(args=['--no-sandbox'])
        pg = b.new_page(viewport={'width': 1920, 'height': 1080})
        pg.goto(html.as_uri()); pg.wait_for_timeout(500); pg.evaluate("render(0)")
        pg.evaluate("Promise.all([document.fonts.load('40px Kalpurush'),document.fonts.load('700 40px DejaVu Sans'),document.fonts.ready])")
        pg.evaluate("Promise.all([...document.images].map(i=>i.complete?1:new Promise(r=>i.onload=r)))")
        pg.wait_for_timeout(300)
        for f in range(s, e):
            pg.evaluate(f"render({f / fps})")
            pg.screenshot(path=str(frames / f"{f:05d}.jpg"), type='jpeg', quality=92)
        b.close()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--seconds', type=float, default=0)
    ap.add_argument('--workers', type=int, default=2)
    ap.add_argument('--fps', type=int, default=30)
    a = ap.parse_args()
    voice, script = HERE / 'input/voice.mp3', HERE / 'input/script.txt'
    if not voice.exists() or not script.exists():
        sys.exit('input/voice.mp3 আর input/script.txt লাগবে')
    print('ভয়েসের সাথে লেখার টাইমিং মেলানো হচ্ছে...')
    beats = make_timeline.build(str(script), str(voice), str(HERE / 'timeline.json'))
    tl = json.load(open(HERE / 'timeline.json', encoding='utf-8'))
    (HERE / 'timeline.js').write_text('window.TL=' + json.dumps(tl, ensure_ascii=False) + ';', encoding='utf-8')
    shutil.copy(HERE / 'template.html', HERE / 'video.html')
    dur = min(tl['duration'], a.seconds) if a.seconds else tl['duration']
    total = math.ceil(dur * a.fps)
    frames = HERE / 'frames'; shutil.rmtree(frames, ignore_errors=True); frames.mkdir()
    step = math.ceil(total / a.workers)
    jobs = [(HERE / 'video.html', frames, i, min(total, i + step), a.fps) for i in range(0, total, step)]
    print(f'{total} ফ্রেম রেন্ডার হচ্ছে...'); t0 = time.time()
    with Pool(len(jobs)) as pool: pool.map(chunk, jobs)
    print(f'ফ্রেম শেষ ({time.time()-t0:.0f}s), FFmpeg...')
    out = HERE / 'output'; out.mkdir(exist_ok=True)
    subprocess.run(['ffmpeg', '-y', '-v', 'error', '-framerate', str(a.fps), '-i', str(frames / '%05d.jpg'), '-i', str(voice),
        '-t', f'{dur:.3f}', '-c:v', 'libx264', '-preset', 'medium', '-crf', '18', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k',
        '-af', 'loudnorm=I=-16:TP=-1.5:LRA=11', '-movflags', '+faststart', str(out / 'video.mp4')], check=True)
    shutil.rmtree(frames, ignore_errors=True)
    print('তৈরি:', out / 'video.mp4')
if __name__ == '__main__': main()
