#!/usr/bin/env python3
"""voice.mp3 + script.txt -> timeline.json (auto-aligns each script line to the voice)."""
import json, re, subprocess, sys, wave, tempfile, os
import numpy as np
from scipy.signal import find_peaks, butter, filtfilt

BN_CONS = set('কখগঘঙচছজঝঞটঠডঢণতথদধনপফবভমযরলশষসহড়ঢ়য়ৎ')
BN_VOW = set('অআইঈউঊঋএঐওঔ')

def syl_word(w):
    n = 0
    # Bengali
    chars = list(w)
    bn = [i for i, c in enumerate(chars) if '\u0980' <= c <= '\u09ff']
    if bn:
        k = 0
        for i, c in enumerate(chars):
            if c in BN_VOW: k += 1
            elif c in BN_CONS:
                nxt = chars[i + 1] if i + 1 < len(chars) else ''
                if nxt != '্': k += 1
        # schwa deletion: word ending in bare consonant
        last = chars[-1] if chars else ''
        if k >= 2 and last in BN_CONS: k -= 1
        n += max(k, 1)
        rest = ''.join(c for c in chars if not ('\u0980' <= c <= '\u09ff'))
    else:
        rest = w
    # Latin parts
    for tok in re.findall(r'[A-Za-z]+', rest):
        if tok.isupper() and len(tok) <= 4: n += len(tok)
        else: n += max(1, len(re.findall(r'[aeiouyAEIOUY]+', tok)))
    return n

def syl(text):
    return sum(syl_word(w) for w in re.split(r'\s+', text) if re.search(r'[\u0980-\u09ffA-Za-z]', w))

def load_script(path):
    beats = []
    for raw in open(path, encoding='utf-8'):
        line = raw.strip()
        if not line or line.startswith('#'): continue
        parts = [p.strip() for p in line.split('|')]
        typ = parts[0]
        text = parts[1] if len(parts) > 1 else ''
        extra = parts[2] if len(parts) > 2 else ''
        plain = text.replace('*', '')
        beats.append(dict(type=typ, raw=text, text=plain, extra=extra, syl=max(1, syl(plain))))
    return beats

def audio_env(audio):
    tmp = tempfile.mktemp(suffix='.wav')
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', audio, '-ac', '1', '-ar', '16000', tmp], check=True)
    w = wave.open(tmp); sr = w.getframerate()
    a = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(float); w.close(); os.remove(tmp)
    dur = len(a) / sr
    # speech activity (10 ms)
    hop = int(sr * .01); n = len(a) // hop
    rms = np.sqrt(np.mean(a[:n * hop].reshape(n, hop) ** 2, axis=1))
    db = 20 * np.log10(rms / 32768 + 1e-9)
    # syllable-nucleus envelope (5 ms, band-passed, ~40 ms smoothing)
    b, c = butter(2, [300 / (sr / 2), 3000 / (sr / 2)], 'band'); x = filtfilt(b, c, a)
    h2 = int(sr * .005); n2 = len(x) // h2
    env = np.sqrt(np.mean(x[:n2 * h2].reshape(n2, h2) ** 2, axis=1))
    env = np.convolve(env, np.ones(8) / 8, 'same')
    edb = 20 * np.log10(env / 32768 + 1e-9)
    pk, _ = find_peaks(edb, prominence=3, distance=int(.09 * 200))
    pk = [p for p in pk if edb[p] > -45]
    peaks = np.array(pk) / 200.0
    speech = db > -38
    return dur, speech, peaks

def pauses_from(speech, min_gap=.15):
    # list of (start, end) pauses at least min_gap long, plus leading/trailing silence trimmed
    n = len(speech); idx = np.where(speech)[0]
    first, last = idx[0] / 100.0, (idx[-1] + 1) / 100.0
    gaps = []; i = idx[0]
    while i < idx[-1]:
        if not speech[i]:
            j = i
            while not speech[j]: j += 1
            if (j - i) / 100.0 >= min_gap: gaps.append((i / 100.0, j / 100.0))
            i = j
        else: i += 1
    return first, last, gaps

def align(beats, peaks, first, last, gaps, lam=20.0):
    P = len(peaks)
    # candidate cut positions in "peak index" space; a cut at k means beat boundary before peak k (0..P)
    gap_cuts = set()
    for g0, g1 in gaps:
        k = int(np.searchsorted(peaks, (g0 + g1) / 2))
        gap_cuts.add(k)
    cand = [0] + sorted(set(range(1, P)) | gap_cuts) + [P]
    pen = {k: (0.0 if k in gap_cuts or k in (0, P) else lam) for k in cand}
    K = len(beats); S = np.array([b['syl'] for b in beats], float)
    scale = P / S.sum(); want = S * scale
    cum = np.concatenate([[0], np.cumsum(peaks * 0 + 1)])  # peaks count helper
    INF = 1e18; m = len(cand)
    dp = np.full((K + 1, m), INF); par = np.zeros((K + 1, m), int)
    dp[0][0] = 0
    for i in range(1, K + 1):
        for b in range(1, m):
            kb = cand[b]; best = INF; bp = 0
            lo = 0
            for a in range(0, b):
                if dp[i - 1][a] >= INF: continue
                got = kb - cand[a]
                if got <= 0: continue
                c = dp[i - 1][a] + (got - want[i - 1]) ** 2 + pen[kb]
                if c < best: best, bp = c, a
            dp[i][b] = best; par[i][b] = bp
    # backtrack ending at P
    b = m - 1; cuts = [cand[b]]
    for i in range(K, 0, -1):
        b = par[i][b]; cuts.append(cand[b])
    cuts = cuts[::-1]  # K+1 boundaries in peak-index space
    return cuts

def build(script, audio, out):
    beats = load_script(script)
    dur, speech, peaks = audio_env(audio)
    first, last, gaps = pauses_from(speech)
    cuts = align(beats, peaks, first, last, gaps)
    for i, b in enumerate(beats):
        a, z = cuts[i], cuts[i + 1]
        pk = peaks[a:z]
        if len(pk) == 0:
            t0 = beats[i - 1]['t1'] if i else first; t1 = t0 + .5; pk = np.array([t0, t1])
        t0 = max(first, pk[0] - .12) if i else max(0, first - .02)
        t1 = min(last + .1, pk[-1] + .22)
        b['t0'] = round(float(t0), 2); b['t1'] = round(float(t1), 2)
        # word timings by cumulative syllables
        words = [w for w in re.split(r'\s+', b['text']) if w]
        ws = [max(1, syl_word(w)) for w in words]; tot = sum(ws); cum = 0; wt = []
        for w, s in zip(words, ws):
            k = min(len(pk) - 1, int(round(cum / tot * len(pk))))
            wt.append([w, round(float(pk[k] - .06 if k else b['t0']), 2)]); cum += s
        b['words'] = wt
    # enforce order
    for i in range(1, len(beats)):
        if beats[i]['t0'] < beats[i - 1]['t0'] + .1: beats[i]['t0'] = round(beats[i - 1]['t0'] + .1, 2)
    for b in beats: b.pop('syl', None)
    json.dump(dict(duration=round(dur, 3), beats=beats), open(out, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    return beats

if __name__ == '__main__':
    script = sys.argv[1] if len(sys.argv) > 1 else 'script.txt'
    audio = sys.argv[2] if len(sys.argv) > 2 else 'voice.mp3'
    out = sys.argv[3] if len(sys.argv) > 3 else 'timeline.json'
    bs = build(script, audio, out)
    for b in bs: print(f"{b['t0']:6.2f}-{b['t1']:6.2f} {b['type']:10s} {b['text'][:50]}")
