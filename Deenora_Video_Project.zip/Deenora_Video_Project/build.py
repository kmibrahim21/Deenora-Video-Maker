#!/usr/bin/env python3
"""Deenora video builder: HTML animation -> frames (Chromium) -> MP4 (FFmpeg).

Usage:
  python build.py                     # full video  -> output/Deenora_Promo.mp4
  python build.py --preview           # one still every 5 s -> preview/
  python build.py --seconds 6         # quick test of the first 6 seconds
  python build.py --workers 4         # parallel Chromium processes
"""
import argparse, math, shutil, subprocess, sys, time
from pathlib import Path
from multiprocessing import Pool

HERE = Path(__file__).parent.resolve()


def render_chunk(a):
    html, frames, start, end, fps, w, h, scale = a
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={'width': w, 'height': h}, device_scale_factor=scale)
        pg.goto(html.as_uri())
        pg.wait_for_timeout(500)
        pg.evaluate("render(0)")
        pg.evaluate("Promise.all([document.fonts.load('40px Kalpurush'),document.fonts.load('700 40px DejaVu Sans'),document.fonts.ready])")
        pg.evaluate("Promise.all([...document.images].map(i=>i.complete?1:new Promise(r=>i.onload=r)))")
        pg.wait_for_timeout(300)
        for f in range(start, end):
            out = frames / f"{f:05d}.jpg"
            if out.exists() and out.stat().st_size > 0:
                continue
            pg.evaluate(f"render({f / fps})")
            pg.screenshot(path=str(out), type='jpeg', quality=92)
        b.close()
    return end - start


def audio_duration(audio):
    r = subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration',
                        '-of', 'default=nw=1:nk=1', str(audio)], capture_output=True, text=True)
    return float(r.stdout.strip())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--html', default='video.html')
    ap.add_argument('--audio', default='voice.mp3')
    ap.add_argument('--out', default='output/Deenora_Promo.mp4')
    ap.add_argument('--fps', type=int, default=30)
    ap.add_argument('--width', type=int, default=1920)
    ap.add_argument('--height', type=int, default=1080)
    ap.add_argument('--scale', type=float, default=1.0, help='2 = 4K output')
    ap.add_argument('--workers', type=int, default=0)
    ap.add_argument('--seconds', type=float, default=0, help='render only the first N seconds (test)')
    ap.add_argument('--preview', action='store_true')
    ap.add_argument('--keep-frames', action='store_true')
    a = ap.parse_args()

    if not shutil.which('ffmpeg'):
        sys.exit('FFmpeg পাওয়া যায়নি। README-র ধাপ ২ দেখো।')
    html, audio = HERE / a.html, HERE / a.audio
    dur = audio_duration(audio)
    if a.seconds:
        dur = min(dur, a.seconds)
    total = math.ceil(dur * a.fps)
    frames = HERE / 'frames'
    out = HERE / a.out
    out.parent.mkdir(exist_ok=True)

    if a.preview:
        prev = HERE / 'preview'
        prev.mkdir(exist_ok=True)
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            b = p.chromium.launch()
            pg = b.new_page(viewport={'width': a.width, 'height': a.height})
            pg.goto(html.as_uri()); pg.wait_for_timeout(500)
            pg.evaluate("render(0)")
            pg.evaluate("Promise.all([document.fonts.load('40px Kalpurush'),document.fonts.load('700 40px DejaVu Sans'),document.fonts.ready])")
            pg.evaluate("Promise.all([...document.images].map(i=>i.complete?1:new Promise(r=>i.onload=r)))")
            pg.wait_for_timeout(300)
            t = 1.0
            while t < dur:
                pg.evaluate(f"render({t})")
                pg.screenshot(path=str(prev / f"t{t:06.2f}.jpg"), type='jpeg', quality=90)
                t += 5
            b.close()
        print('Preview ছবি তৈরি হয়েছে:', prev)
        return

    frames.mkdir(exist_ok=True)
    workers = a.workers or max(1, (__import__('os').cpu_count() or 2) // 2)
    workers = min(workers, 8)
    step = math.ceil(total / workers)
    jobs = [(html, frames, i, min(total, i + step), a.fps, a.width, a.height, a.scale)
            for i in range(0, total, step)]
    print(f'{total} ফ্রেম, {len(jobs)} প্রসেস...')
    t0 = time.time()
    with Pool(len(jobs)) as pool:
        pool.map(render_chunk, jobs)
    print(f'ফ্রেম রেন্ডার শেষ ({time.time() - t0:.0f}s). FFmpeg চলছে...')

    cmd = ['ffmpeg', '-y', '-v', 'error', '-framerate', str(a.fps), '-i', str(frames / '%05d.jpg'),
           '-i', str(audio), '-t', f'{dur:.3f}', '-c:v', 'libx264', '-preset', 'medium', '-crf', '18',
           '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k',
           '-af', 'loudnorm=I=-16:TP=-1.5:LRA=11', '-shortest', '-movflags', '+faststart', str(out)]
    subprocess.run(cmd, check=True)
    if not a.keep_frames:
        shutil.rmtree(frames, ignore_errors=True)
    print('তৈরি হয়েছে:', out)


if __name__ == '__main__':
    main()
